# 📄 user.json — Profile Information

**id:** user-1kGieXGmJgFC521QKCh8mmDi

**email:** admin@omniversalmedia.cc

**chatgpt_plus_user:** True

**birth_year:** 1989

**phone_number:** +14344290117

